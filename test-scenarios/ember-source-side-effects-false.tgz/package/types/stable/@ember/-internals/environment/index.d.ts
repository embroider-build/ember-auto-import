declare module '@ember/-internals/environment' {
    export * from "@ember/-internals/environment/lib/context";
    export * from "@ember/-internals/environment/lib/env";
}