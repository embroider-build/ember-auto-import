declare module '@ember/template-compiler/lib/-internal/primitives' {
    export { RESOLUTION_MODE_TRANSFORMS, STRICT_MODE_TRANSFORMS, STRICT_MODE_KEYWORDS, INTERNAL_PLUGINS, } from "@ember/template-compiler/lib/plugins";
}