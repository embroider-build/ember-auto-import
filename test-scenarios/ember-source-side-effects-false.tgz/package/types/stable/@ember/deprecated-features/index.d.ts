declare module '@ember/deprecated-features' {
    /** Introduced in 4.0.0-beta.1 */
    export const ASSIGN = true;
}