declare module '@glimmer/runtime/lib/bootstrap' {
    import "@glimmer/runtime/lib/opcodes";
    import "@glimmer/runtime/lib/compiled/opcodes/expressions";
    import "@glimmer/runtime/lib/compiled/opcodes/component";
    import "@glimmer/runtime/lib/compiled/opcodes/content";
    import "@glimmer/runtime/lib/compiled/opcodes/debugger";
    import "@glimmer/runtime/lib/compiled/opcodes/dom";
    import "@glimmer/runtime/lib/compiled/opcodes/vm";
    import "@glimmer/runtime/lib/compiled/opcodes/lists";
}