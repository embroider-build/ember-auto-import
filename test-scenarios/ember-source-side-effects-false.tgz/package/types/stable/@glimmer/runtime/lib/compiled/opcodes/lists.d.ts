declare module '@glimmer/runtime/lib/compiled/opcodes/lists' {
    export {};
}