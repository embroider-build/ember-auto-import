declare module '@glimmer/runtime/lib/helpers/and' {
    export const and: object;
}