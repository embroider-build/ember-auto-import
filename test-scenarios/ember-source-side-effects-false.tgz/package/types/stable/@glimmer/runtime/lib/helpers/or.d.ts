declare module '@glimmer/runtime/lib/helpers/or' {
    export const or: object;
}