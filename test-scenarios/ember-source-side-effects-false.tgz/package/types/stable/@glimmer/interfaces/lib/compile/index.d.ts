declare module '@glimmer/interfaces/lib/compile' {
    export type * from "@glimmer/interfaces/lib/compile/encoder.js";
    export type * from "@glimmer/interfaces/lib/compile/instruction-encoder.js";
    export type * from "@glimmer/interfaces/lib/compile/operands.js";
    export type * from "@glimmer/interfaces/lib/compile/wire-format/api.js";
}