declare module '@glimmer/opcode-compiler/lib/opcode-builder/opcodes' {
    export const HighLevelResolutionOpcodes: {
        readonly Modifier: 1003;
        readonly Component: 1004;
        readonly Helper: 1005;
        readonly ComponentOrHelper: 1007;
        readonly OptionalComponentOrHelper: 1008;
        readonly Local: 1010;
        readonly TemplateLocal: 1011;
    };
    export const HighLevelBuilderOpcodes: {
        readonly Label: 1000;
        readonly StartLabels: 1001;
        readonly StopLabels: 1002;
        readonly Start: 1000;
        readonly End: 1002;
    };
}