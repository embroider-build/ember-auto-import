declare module '@glimmer/compiler/lib/passes/1-normalization/keywords/utils/call-to-append' {
    import type { GenericKeywordNode, KeywordDelegate } from "@glimmer/compiler/lib/passes/1-normalization/keywords/impl";
    import * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    export function toAppend<T>(
      { assert, translate, }: KeywordDelegate<GenericKeywordNode, T, mir.ExpressionNode>
    ): KeywordDelegate<GenericKeywordNode, T, mir.AppendTextNode>;
}