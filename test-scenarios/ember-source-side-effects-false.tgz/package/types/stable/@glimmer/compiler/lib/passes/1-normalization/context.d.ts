declare module '@glimmer/compiler/lib/passes/1-normalization/context' {
    import type { ASTv2, SymbolTable } from "@glimmer/syntax";
    import type { OptionalList } from "@glimmer/compiler/lib/shared/list";
    import type { Result } from "@glimmer/compiler/lib/shared/result";
    import type * as mir from "@glimmer/compiler/lib/passes/2-encoding/mir";
    /**
     * This is the mutable state for this compiler pass.
     */
    export class NormalizationState {
        readonly isStrict: boolean;
        _currentScope: SymbolTable;
        _cursorCount: number;
        constructor(block: SymbolTable, isStrict: boolean);
        generateUniqueCursor(): string;
        get scope(): SymbolTable;
        visitBlock(block: ASTv2.Block): Result<OptionalList<mir.Statement>>;
    }
}